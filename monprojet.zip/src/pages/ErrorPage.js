import React from 'react';

const ErrorPage = () => {
    return <h1>ERREUR</h1>;
};

export default ErrorPage;