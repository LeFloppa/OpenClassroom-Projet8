import React from 'react';

const AboutPage = () => {
    return <h1>À propos</h1>;
};

export default AboutPage;