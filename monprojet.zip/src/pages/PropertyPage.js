import React from 'react';

const PropertyPage = () => {
    return <h1>Propriétés</h1>;
};

export default PropertyPage;